<?php
session_start();

if(!isset($_SESSION["login"])) {
    header ("location:login.php?pesan=loginduluu");
}

include "koneksi.php";
$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    .geeks {
        width: 595px;
        height: 300px;
        overflow: hidden;
        margin: 0 auto;
    }
      
    .geeks img {
        width: 100%;
        transition: 1s all;
    }
      
    .geeks:hover img {
        transform: scale(1.5);
    }
</style>
   
    <title>SALAD.COM</title>
    <link rel="shortcut icon" href="images/saladd.png" type="image/x-icon">

    <nav class="navbar navbar-expand-lg bg-secondary  sticky-top" data-bs-theme="primary">
  <div class="container-fluid">
  <img src="images/saladd.png" width="60" height="60" alt="">
    <a class="navbar-brand tex" href="#">SALAD.COM</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link active" href="#">
            <span class="visually-hidden">(current)</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"></a>
        </li>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="#">Action</a>
            <a class="dropdown-item" href="#">Another action</a>
            <a class="dropdown-item" href="#">Something else here</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Separated link</a>
          </div>
        </li>
      </ul>
      <form class="d-flex">
        <!-- Button trigger modal -->
        <span>
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
  +
</button>
        <a href="logout.php" class="btn btn-danger" onclick="return confirm('yakin mau logout?')"><i class="bi bi-box-arrow-right"></i></a>
        </span>
      </form>
    </div>
  </div>
</nav>
</head>
<body>
    
<?php while($post = mysqli_fetch_assoc($query)) { ?>
  
   <div class="container mt-5">
     <div class="row justify-content-center">
       <div class="col-md-6">
    <div class="card mt-5" >
   <div class="geeks">
   <img src="images/<?= $post['foto'] ?>" class="card-img-top" width="100" height="500" alt="...">
   </div>
</div>   

   <div class="card-body card-body-cascade text-center pb-0">
       <p class="card-text text-center" style="font-size:14px"><?=$post['lokasi'] ?></p>
       <h5 class="card-title text-center"><?=$post['caption'] ?></h5>
       <a href="" type="button" data-bs-toggle="modal" data-bs-target="#edit<?=$post['no']?>"><i class="btn btn-outline-dark bi bi-pencil" style="font-size:20px"></i></a>
       <a href="hapus.php?no=<?=$post['no']?>" onclick="return confirm('hapus postingan ini?')"><i class="btn btn-outline-danger bi bi-trash" style="font-size:20px;"></i></a>
      
   </div>
   </div>
   </div>
   </div>
   
   <!-- modal edit -->
  <div class="modal fade" id="edit<?= $post['no'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">
  <div class="modal-header">
  <h1 class="modal-title fs-5" id="exampleModalLabel">Edit</h1>
  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
  </div>

  <div class="modal-body">
  <form action="proses_edit.php" method="post" enctype="multipart/form-data">
  <input type="hidden" name="no" value="<?= $post['no'] ?>">
    <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">
    
        <label class="form-label" for="">Gambar</label>
        <input class="form-control" type="file" name="foto" id="" value="<?= $post['foto'] ?>" ><br>
        <img src="images/<?= $post['foto'] ?>" width="200" alt="" ><br><br>

        <div class="col-auto">
        <label class="form-label" for="">Caption</label>
        </div>

        <input class="form-control" type="text" name="caption"value="<?= $post['caption'] ?>" id="" autocomplete="off"><br>

        <label class="form-label" for="">Lokasi</label>
        <input class="form-control" type="text" name="lokasi" value="<?= $post['lokasi'] ?>" id="" autocomplete="off"><br>


    <button type="submit" class="btn btn-dark" value="Update" name="update">Ubah</button>
    </div>
    </div>
  </div>
</div>

   </form>
   <?php } ?>





   <!-- Modal -->
<form action="proses_tambah.php" method="post" enctype="multipart/form-data">
<div class="modal fade" id="modalTambah" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">TAMBAH DATA</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
     
        <label for="">Foto</label><br>
        <input type="file" name="foto" id="" required><br>
        <label for="">Caption</label><br>
        <input type="text" name="caption" id="" autocomplete="off"><br>
        <label for="">Lokasi</label><br>
        <input type="text" name="lokasi" id="" autocomplete="off"><br><br>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Simpan" name="simpan">
      </div>
    </div>
  </div>
</div>
</form>




</body>
</html>